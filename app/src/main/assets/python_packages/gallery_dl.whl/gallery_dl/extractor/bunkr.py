# -*- coding: utf-8 -*-

# Copyright 2022-2026 Mike Fährmann
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 as
# published by the Free Software Foundation.

"""Extractors for https://bunkr.cr/"""

from .common import Extractor
from .lolisafe import LolisafeAlbumExtractor
from .. import text, util, config
import random

if config.get(("extractor", "bunkr"), "tlds"):
    BASE_PATTERN = (
        r"(?:bunkr:(?:https?://)?([^/?#]+)|"
        r"(?:https?://)?(?:app\.)?(bunkr+\.\w+))"
    )
else:
    BASE_PATTERN = (
        r"(?:bunkr:(?:https?://)?([^/?#]+)|"
        r"(?:https?://)?(?:app\.)?(bunkr+"
        r"\.(?:s[kiu]|c[ir]|fi|p[hks]|ru|la|is|to|a[cx]"
        r"|black|cat|media|red|site|ws|org)))"
    )

DOMAINS = [
    "bunkr.ac",
    "bunkr.ci",
    "bunkr.cr",
    "bunkr.fi",
    "bunkr.ph",
    "bunkr.pk",
    "bunkr.ps",
    "bunkr.si",
    "bunkr.sk",
    "bunkr.ws",
    "bunkr.black",
    "bunkr.red",
    "bunkr.media",
    "bunkr.site",
]
LEGACY_DOMAINS = {
    "bunkr.ax",
    "bunkr.cat",
    "bunkr.ru",
    "bunkrr.ru",
    "bunkr.su",
    "bunkrr.su",
    "bunkr.la",
    "bunkr.is",
    "bunkr.to",
}
CF_DOMAINS = set()


class BunkrAlbumExtractor(LolisafeAlbumExtractor):
    """Extractor for bunkr albums"""
    category = "bunkr"
    root = "https://bunkr.cr"
    root_api = "https://dl.bunkr.cr"
    root_sign = "https://glb-apisign.cdn.cr"
    archive_fmt = "{album_id}_{id|id_url|slug}"
    pattern = BASE_PATTERN + r"/a/([^/?#]+)"
    example = "https://bunkr.cr/a/ID"

    def __init__(self, match):
        LolisafeAlbumExtractor.__init__(self, match)
        domain = self.groups[0] or self.groups[1] or "bunkr.cr"
        if domain not in LEGACY_DOMAINS:
            self.root = "https://" + domain

    def _init(self):
        LolisafeAlbumExtractor._init(self)

        endpoint = self.config("endpoint")
        if not endpoint:
            endpoint = self.root_api + "/api/_001_v2"
        elif endpoint[0] == "/":
            endpoint = self.root_api + endpoint

        self.endpoint = endpoint
        self.offset = 0

    def skip_files(self, num):
        self.offset = num
        return num

    def request(self, url, **kwargs):
        kwargs["encoding"] = "utf-8"
        kwargs["allow_redirects"] = False

        while True:
            try:
                response = Extractor.request(self, url, **kwargs)
                if response.status_code < 300:
                    return response

                # redirect
                url = response.headers["Location"]
                if url[0] == "/":
                    url = self.root + url
                    continue
                root, path = self._split(url)
                if root not in CF_DOMAINS:
                    continue
                self.log.debug("Redirect to known CF challenge domain '%s'",
                               root)

            except self.exc.HttpError as exc:
                if exc.status != 403:
                    raise

                # CF challenge
                root, path = self._split(url)
                CF_DOMAINS.add(root)
                self.log.debug("Added '%s' to CF challenge domains", root)

                try:
                    DOMAINS.remove(root.rpartition("/")[2])
                except ValueError:
                    pass
                else:
                    if not DOMAINS:
                        raise self.exc.AbortExtraction(
                            "All Bunkr domains require solving a CF challenge")

            # select alternative domain
            self.root = root = "https://" + random.choice(DOMAINS)
            self.log.debug("Trying '%s' as fallback", root)
            url = root + path

    def fetch_album(self, album_id):
        # album metadata
        page = self.request(f"{self.root}/a/{album_id}?advanced=1").text
        title = text.unescape(text.unescape(text.extr(
            page, 'property="og:title" content="', '"')))

        # files
        items = text.extr(
            page, "window.albumFiles = [", "</script>").split("\n},\n")

        return self._extract_files(items), {
            "album_id"   : album_id,
            "album_name" : title,
            "album_size" : text.extr(
                page, '<span class="font-semibold">(', ')'),
            "count"      : len(items),
        }

    def _extract_files(self, items):
        if self.offset:
            items = util.advance(items, self.offset)

        for item in items:
            try:
                data_id = text.extr(item, " id: ", ",").strip()
                file = self._extract_file(data_id)

                file["name"] = util.json_loads(text.extr(
                    item, 'original:', ',\n').replace("\\'", "'"))
                file["slug"] = util.json_loads(text.extr(
                    item, 'slug: ', ',\n').replace("\\'", "'"))
                file["uuid"] = text.extr(
                    item, 'name: "', ".")
                file["size"] = text.parse_int(text.extr(
                    item, "size:  ", " ,\n"))
                file["date"] = self.parse_datetime(text.extr(
                    item, 'timestamp: "', '"'), "%H:%M:%S %d/%m/%Y")
                tn = text.extr(item, "thumbnail: ", ",\n").replace("\\'", "'")
                file["thumbnail"] = util.json_loads(tn) if tn else None

                yield file
            except self.exc.ControlException:
                raise
            except Exception as exc:
                self.log.error("%s: %s", exc.__class__.__name__, exc)
                self.log.debug("%s", item, exc_info=exc)
                if isinstance(exc, self.exc.HttpError) and \
                        exc.status == 400 and \
                        exc.response.url.startswith(self.root_api):
                    raise self.exc.AbortExtraction("Album deleted")

    def _extract_file(self, data_id):
        headers = {
            "Referer": self.root_api + "/",
            "Origin" : self.root_api,
        }

        url = self.endpoint
        file = self.request_json(
            url, method="POST", headers=headers, json={"id": data_id})

        url = self.root_sign + "/sign"
        sign = self.request_json(
            url, params={"path": file["path"]}, headers=headers)
        if "original" in file:
            sign["n"] = file["original"]

        del headers["Origin"]
        return {
            "file"          : (f"{file['mediafiles']}{file['path']}"
                               f"?{text.build_query(sign)}"),
            "id_url"        : data_id,
            "_http_headers" : headers,
            "_http_validate": self._validate,
        }

    def _validate(self, response):
        if response.history and response.url.endswith(
                ("/maint.mp4", "/maintenance-vid.mp4")):
            self.log.warning("File server in maintenance mode")
            return False
        return True

    def _split(self, url):
        pos = url.index("/", 8)
        return url[:pos], url[pos:]


class BunkrMediaExtractor(BunkrAlbumExtractor):
    """Extractor for bunkr media links"""
    subcategory = "media"
    directory_fmt = ("{category}",)
    pattern = BASE_PATTERN + r"(/[fvid]/[^/?#]+)"
    example = "https://bunkr.cr/f/FILENAME"

    def fetch_album(self, album_id):
        try:
            page = self.request(self.root + album_id).text
            data_id = text.extr(page, 'data-file-id="', '"')
            file = self._extract_file(data_id)
            file["name"] = text.unquote(text.unescape(text.extr(
                page, "<h1", "<").rpartition(">")[2]))
            file["slug"] = album_id.rpartition("/")[2]
            file["uuid"] = text.extr(page, "/thumbs/", ".")
            tn = text.extr(page, 'property="og:image" content="', '"')
            file["thumbnail"] = text.unescape(tn) if tn else None
        except Exception as exc:
            self.log.error("%s: %s", exc.__class__.__name__, exc)
            return (), {}

        album_id, album_name, album_size = self.cache(
            self._album_info, text.extr(page, ' href="../a/', '"'))
        return (file,), {
            "album_id"  : album_id,
            "album_name": album_name,
            "album_size": album_size,
            "count"     : 1,
        }

    def _album_info(self, album_id):
        if album_id:
            try:
                page = self.request(f"{self.root}/a/{album_id}").text
                return (
                    album_id,
                    text.unescape(text.unescape(text.extr(
                        page, 'property="og:title" content="', '"'))),
                    text.extr(page, '<span class="font-semibold">(', ')'),
                )
            except Exception:
                pass
        return album_id, "", -1


class BunkrDirectLinkExtractor(BunkrMediaExtractor):
    subcategory = "direct-link"
    pattern = r"https://cdn\d*\.bunkr\.ru()()(/.+)"
    example = "https://cdn123.bunkr.ru/NAME-ID.EXT"

    def fetch_album(self, album_id):
        return BunkrMediaExtractor.fetch_album(self, "/f" + album_id)
